import sys
import random
import copy
import time

BLANK = 0
DOMAIN = [1, 2, 3, 4, 5, 6, 7, 8, 9]

global nodesExpanded
nodesExpanded = 0
global untriedValues
untriedValues = {}
global blanks
blanks = {}


def printMatrix(matrix):
    for r in matrix:
        for c in r:
            print(c, end=" ")
        print()


def valInBox(boxIdx, val, matrix):
    box = []
    shift = boxIdx % 3
    for r in range(3):
        for c in range(3):
            # print("r, c", [r + boxIdx - shift, c + shift * 3])
            box.append(matrix[r + boxIdx - shift][c + shift * 3])
    return val in box


def valInCol(colIdx, val, matrix):
    for row in matrix:
        if val == row[colIdx]:
            return True
    return False


def valInRow(rowIdx, val, matrix):
    return val in matrix[rowIdx]


def findAllBlanks(matrix):
    global blanks
    for r in range(len(matrix)):
        for c in range(len(matrix[r])):
            if matrix[r][c] == BLANK:
                blanks[str(r) + str(c)] = [r, c]


def findRandBlank(blanks):
    if not blanks:
        return None
    randBlank = random.choice(list(blanks.keys()))
    return (blanks[randBlank], randBlank)


def findNextBlank(matrix):
    for r in range(len(matrix)):
        for c in range(len(matrix[r])):
            if matrix[r][c] == BLANK:
                return (r, c)
    return None


def findRandomVal(untriedVals):
    idx = random.randint(0, len(untriedVals) - 1)
    return (untriedVals[idx], idx)


def getBox(row, col):
    if row < 3:
        if col < 3:
            return 0
        elif col < 6:
            return 1
        else:
            return 2
    elif row < 6:
        if col < 3:
            return 3
        elif col < 6:
            return 4
        else:
            return 5
    elif row < 9:
        if col < 3:
            return 6
        elif col < 6:
            return 7
        else:
            return 8


def tryAssignA(matrix):
    global blanks
    global nodesExpanded
    nextBlankInfo = findRandBlank(blanks)
    if not nextBlankInfo:
        # we're done and assigned all blanks in the puzzle
        print("Total Nodes expanded: ", nodesExpanded)
        return True
    else:
        row = nextBlankInfo[0][0]
        col = nextBlankInfo[0][1]
        nextBlankKey = nextBlankInfo[1]
        print("tryAssignA called for", [row, col])

    untriedVals = copy.deepcopy(DOMAIN)
    while untriedVals:
        print(row, col)
        print(untriedVals)
        val, valIdx = findRandomVal(untriedVals)
        untriedVals.pop(valIdx)

        inCol = valInCol(col, val, matrix)
        inRow = valInRow(row, val, matrix)
        inBox = valInBox(getBox(row, col), val, matrix)

        if not inCol and not inRow and not inBox:
            print(str(val) + " chosen for", [row, col])
            matrix[row][col] = val
            nodesExpanded += 1
            printMatrix(matrix)
            print(nodesExpanded)

            print("blanks", blanks)
            print("poppng ", [row, col])
            del blanks[nextBlankKey]

            print("owner:", [row, col])
            if tryAssignA(matrix):
                return True
            print(str(val) + " chosen for ",
                  [row, col], "didn't work, resetting...")
            matrix[row][col] = 0
            blanks[str(row) + str(col)] = [row, col]
    print("no more values for ", [row, col], ", backtracking")
    return False


def tryAssignB(matrix, blanks):
    global nodesExpanded
    nextBlank, nextBlankIdx = findRandBlank(blanks)
    if not nextBlank:
        # we're done and assigned all blanks in the puzzle
        print("Total Nodes expanded: ", nodesExpanded)
        return True
    else:
        row = nextBlank[0]
        col = nextBlank[1]

    # print(row, col)
    untriedVals = untriedValues[str(row) + str(col)]
    while untriedVals:
        print(untriedVals)
        val, valIdx = findRandomVal(untriedVals)
        untriedVals.pop(valIdx)

        inCol = valInCol(col, val, matrix)
        inRow = valInRow(row, val, matrix)
        inBox = valInBox(getBox(row, col), val, matrix)

        if not inCol and not inRow and not inBox:
            # print(row, col)
            # print(untriedVals)
            print(str(val) + " chosen for ", [row, col])
            matrix[row][col] = val
            # forward check other affected variables
            nodesExpanded += 1
            printMatrix(matrix)
            print(nodesExpanded)

            print("poppng", blanks.pop(nextBlankIdx))

            print("owner: ", [row, col])
            if tryAssignB(matrix, blanks):
                return True
            print(str(val) + " chosen for ",
                  [row, col], "didn't work, resetting...")
            matrix[row][col] = 0
            blanks.append([row, col])
    return False


def versionA():
    global blanks
    matrix = []
    for line in sys.stdin:
        rowAsStr = line.strip().split(" ")
        matrix.append([int(x) for x in rowAsStr])
    findAllBlanks(matrix)
    solved = tryAssignA(matrix)
    if solved:
        printMatrix(matrix)
    else:
        print("Sudoku puzzle not solvable")


def versionB():
    matrix = []
    for line in sys.stdin:
        rowAsStr = line.strip().split(" ")
        matrix.append([int(x) for x in rowAsStr])
    blanks = findAllBlanks(matrix)
    for x in blanks:
        rowColStr = str(x[0]) + str(x[1])
        untriedValues[rowColStr] = copy.deepcopy(DOMAIN)
    solved = tryAssignB(matrix, blanks)
    if solved:
        printMatrix(matrix)
    else:
        print("Sudoku puzzle not solvable")


def versionC():
    pass


startTime = time.time()
if sys.argv[1] == "A":
    versionA()
    endTime = time.time()
    executionTime = endTime - startTime
    print("Execution time: ", executionTime)
elif sys.argv[1] == "B":
    versionB()
elif sys.argv[1] == "C":
    versionC()
